# Proyecto Final — Sitio Web Accesible

Este repositorio contiene el proyecto final con:
- Tres páginas (`index.html`, `gallery.html`, `about.html`).
- Estilos en `css/styles.css` usando grid, flex y modelo de caja.
- Accesibilidad: enlace "Saltar al contenido principal" y roles ARIA.
- Validado con W3C Validator y WAVE.

## Publicación
El sitio está configurado para usarse con GitHub Pages. Activa Pages en Settings > Pages seleccionando la rama `main`.

